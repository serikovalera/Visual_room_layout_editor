#include "xmlitemabstract.h"

XMLItemAbstract::XMLItemAbstract()
{

}
