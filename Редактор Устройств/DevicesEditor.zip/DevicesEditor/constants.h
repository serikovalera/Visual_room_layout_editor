#ifndef CONSTANTS_H
#define CONSTANTS_H

const float GRID_SIZE = 20; ///< Размер клеток сетки
const float PLAN_PADDING = 200; ///< Отступ схемы

const float SCENE_SIZE = 10000; ///< Размер сцены

#endif // CONSTANTS_H
