#include "datavalidators.h"

DataValidators::DataValidators()
{

}
