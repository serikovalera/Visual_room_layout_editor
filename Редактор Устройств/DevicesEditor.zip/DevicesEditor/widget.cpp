#include "widget.h"
#include "ui_widget.h"
#include "xml/filereader.h"

#include <QDebug>
#include <QFileDialog>
#include <QShortcut>
#include <qmessagebox.h>

Widget::Widget(QWidget *parent) : QWidget(parent), ui(new Ui::Widget)
{
    ui->setupUi(this);

    graphicsScene = new GraphicsScene();
    graphicsView = new GraphicsView(graphicsScene);
    graphicsView->setRenderHints(QPainter::Antialiasing | QPainter::SmoothPixmapTransform);

    graphicsView->setAlignment(Qt::AlignTop | Qt::AlignLeft);

    graphicsView->setScene(graphicsScene);
    graphicsView->setSceneRect(0, 0, SCENE_SIZE, SCENE_SIZE);
    graphicsScene->setSceneRect(0, 0, SCENE_SIZE, SCENE_SIZE);

    this->graphicsScene->drawStripes();
    this->ui->editorLayout->addWidget(graphicsView);

    QShortcut *openShortcut = new QShortcut(QKeySequence::Open, this);
    QShortcut *saveAsShortcut = new QShortcut(QKeySequence::SaveAs, this);
    QShortcut *saveShortcut = new QShortcut(QKeySequence::Save, this);

    connect(openShortcut, &QShortcut::activated, this, &Widget::on_openBtn_pressed);
    connect(saveAsShortcut, &QShortcut::activated, this, &Widget::on_saveAsBtn_pressed);
    connect(saveShortcut, &QShortcut::activated, this, &Widget::on_saveBtn_pressed);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_arrowBtn_toggled(bool checked)
{
    this->ui->dragBtn->setChecked(!checked);
    this->graphicsView->setDrag(!checked);
}

void Widget::on_dragBtn_toggled(bool checked)
{
    this->ui->arrowBtn->setChecked(!checked);
    this->graphicsView->setDrag(checked);
}

void Widget::on_openBtn_pressed()
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Открытие файла"), "", tr("XML Файлы (*.xml)"));

    if (!fileName.isEmpty()) {
        try {
            House* house = FileReader::readFile(fileName);
            this->graphicsScene->setPlanning(house);
            QMessageBox::information(this, tr("Загрузка файла"), tr("Файл успешно загружен!"));

        } catch (const std::exception& e) {
            QMessageBox::critical(this, tr("Ошибка"), tr("Ошибка при загрузке файла: %1").arg(e.what()));
        }
    }
}

void Widget::on_saveAsBtn_pressed()
{
    if (this->graphicsScene->getPlanning() == nullptr)
        return;

    QString fileName = QFileDialog::getSaveFileName(this, tr("Сохранение файла"), "", tr("XML Файлы (*.xml)"));

    if (fileName.isEmpty()) {
        return;
    }

    savePlanning(fileName);
}

void Widget::on_saveBtn_pressed()
{
    if (this->graphicsScene->getPlanning() == nullptr)
        return;

    savePlanning();
}

void Widget::savePlanning(QString filename)
{
    auto devices = this->graphicsScene->getPlanning()->getDevices();

    bool ipUnset = false;

    for (auto device : devices) {
        if (device->getIp().isEmpty())
            ipUnset = true;

        if (device->isColliding()) {
            QMessageBox::critical(this, "Ошибка", "Невозможно сохранить схему! Некоторые устройства расположены некорректно.");
            return;
        }
    }

    if (ipUnset) {
        QMessageBox::StandardButton reply = QMessageBox::question(this, "Подтверждение", "Некоторые устройства не имеют IP-адресов. Вы действительно хотите сохранить схему?", QMessageBox::Yes|QMessageBox::No);
        if (reply == QMessageBox::No) {
            return;
        }
    }

    if (!FileReader::writeFile(this->graphicsScene->getPlanning(), filename)) {
        QMessageBox::critical(this, tr("Ошибка"), tr("Не удалось сохранить файл!"));
    } else {
        QMessageBox::information(this, "Успех", "Файл успешно сохранен!");
    }
}
