#include "pc.h"

PC::PC() : DeviceAbstract("pc", QPixmap(":/icons/pc.png"), 100, 80, 100)
{

}
