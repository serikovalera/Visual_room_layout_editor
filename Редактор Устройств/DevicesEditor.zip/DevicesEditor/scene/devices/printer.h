#ifndef PRINTER_H
#define PRINTER_H

#include "deviceabstract.h"

/**
 *@brief Класс, представляющий принтер.
 */
class Printer : public DeviceAbstract
{
public:
    Printer();
};

#endif // PRINTER_H
