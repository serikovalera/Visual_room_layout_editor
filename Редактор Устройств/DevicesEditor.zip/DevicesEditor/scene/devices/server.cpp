#include "server.h"

Server::Server() : DeviceAbstract("server", QPixmap(":/icons/server2.png"), 200, 200, 100)
{

}
