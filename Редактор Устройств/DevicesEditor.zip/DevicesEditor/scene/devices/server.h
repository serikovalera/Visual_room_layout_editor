#ifndef SERVER_H
#define SERVER_H

#include "deviceabstract.h"

/**
 *@brief Класс, представляющий сервер.
 */
class Server : public DeviceAbstract
{
public:
    Server();
};

#endif // SERVER_H
