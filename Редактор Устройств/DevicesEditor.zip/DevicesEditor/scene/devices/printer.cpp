#include "printer.h"

Printer::Printer() : DeviceAbstract("printer", QPixmap(":/icons/printer.png"), 60, 60, 40)
{

}
