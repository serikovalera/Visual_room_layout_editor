#ifndef PC_H
#define PC_H

#include "scene/devices/deviceabstract.h"

/**
 *@brief Класс, представляющий компьютер.
 */
class PC : public DeviceAbstract
{
public:
    PC();
};

#endif // PC_H
