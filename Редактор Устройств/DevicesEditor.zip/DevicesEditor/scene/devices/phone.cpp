#include "phone.h"

Phone::Phone() : DeviceAbstract("phone", QPixmap(":/icons/phone.png"), 20, 35, 100) {}
