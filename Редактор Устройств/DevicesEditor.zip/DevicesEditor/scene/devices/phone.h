#ifndef PHONE_H
#define PHONE_H

#include "deviceabstract.h"

/**
 *@brief Класс, представляющий телефон.
 */
class Phone : public DeviceAbstract
{
public:
    Phone();
};

#endif // PHONE_H
